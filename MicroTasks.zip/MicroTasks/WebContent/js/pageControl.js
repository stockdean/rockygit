function funcsrcoll1()  
{  
 
document.getElementById("tt").scrollTop = document.getElementById("pp").scrollTop;  
}  
function funcsrcoll2()  
{  
 
document.getElementById("pp").scrollTop = document.getElementById("tt").scrollTop;  
} 