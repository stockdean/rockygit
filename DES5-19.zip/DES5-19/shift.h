#include<stdio.h> 
#include <stdlib.h>
int* lshift(int a[],int t){
	int i,temp,temp2;
	int *sh;
	sh =(int*)malloc(sizeof(int)*28);
	
	if(t==1)
	    temp=a[0];    	    
	else{
		temp=a[0];
		temp2=a[1];	
		}	
		
	for(i=t;i<28;i++){
				
		a[i-t]=a[i];
		
		
		
	}
	if(t==1)
    a[27]=temp;
    else{
    	a[26]=temp;
    	a[27]=temp2;
	}
	
	sh=a;

temp=0;
temp2=0;
//////////////////////////���� 
//	printf("����%dλ:",t);
//		for(i=0;i<28;i++){
//		
//		printf("%d",sh[i]);
//	}
//	    printf("\n");
//	   

//////////////////////////���� 








    return sh;
}
int* rshift(int a[],int t){
	
	int i,temp,temp2;
	int *sh;
	sh =(int*)malloc(sizeof(int)*28);
	
	if(t==0){
	1;	
	}
	if(t==1)
	    temp=a[27];    	    
	if(t==2){
		temp=a[27];
		temp2=a[26];	
		}	
		
	for(i=27-t;i>=0;i--){
				
		a[i+t]=a[i];
		
		
	}
	if(t==0){
		1;
	}
	if(t==1)
    a[0]=temp;
    if(t==2){
    	a[1]=temp;
    	a[0]=temp2;
	}
	
temp=0;
temp2=0;
	
	
	
	
	
	
	sh=a;
	
	
//////////////////////////���� 
//	printf("����%dλ:",t);
//		for(i=0;i<28;i++){
//		
//		printf("%d",sh[i]);
//	}
//	    printf("\n");
//	   

//////////////////////////���� 	
	
	
	
	
	
	
	
	
	
	
	
	
	

    return sh;
	
	
	
	
	
	
	
	
	
	
}



