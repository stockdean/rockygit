#include<stdio.h>
#include<string.h>
#include "bitopt.h"
int filelen(char a[]){
	
	int len;
	FILE *in;  
    in=fopen(a,"rb"); 
    fseek(in,0,2);
    len=ftell(in);
    fseek(in,0,0);
	fclose(in); 
	return len;
} 

int filefill(char a[],int f){
	char ch;
	int len,i,t;
	FILE *in,*out;  
    in=fopen(a,"rb"); 
    out=fopen("test.txt","w");
    ch=fgetc(in);
    while(ch!=EOF){  
    	fputc(ch,out);
    	ch=fgetc(in);
	}
	
    for(i=0;i<f;i++){
    	
    	fputc('0',out);
    	
	}
	for(i=0;i<7;i++){
		
		
		fputc('0',out);
		
		
	}
	t=f+8;
	if(t>=10){
	 	ch=t-10+'A';
	 		
		 }else{
		 	ch=t+'0';
		 }
		 	 
	fputc(ch,out);
	fclose(in); 
	fclose(out); 
	return t;
}

int *fileget(char a[],int h,int flag){
    char ch;
    char*s;
    int *num;
    int len,temp,tt,cc;
    int i=0,j=0;
    FILE *in,*out;  
    if(flag==3){
    	a="test.txt";
	}
    in=fopen(a,"rb"); 

  
    s=(char*)malloc(sizeof(char)*8);
    num=(int*)malloc(sizeof(int)*64);

fseek(in,8*h,1);
for(i=0;i<8;i++){
   ch=fgetc(in); 
   s[i]=ch;
 //  printf("OX%02x\n",s[i]&0xFF);
}




for(i=0;i<8;i++){

    for(j=0;j<8;j++){
    	num[i*8+j]=getbit(s[i],7-j);
    	
    //	printf("%d",num[i*8+j]);

    
	}
   //    printf("\n");

}
      
    fclose(in); 
    
    free(s);
    return num;
   
}



void fileput(int a[],char f[],int flag){
	FILE *fp;
	int i,j;
	int b[8];
	char *r;
	r=(char*)malloc(sizeof(char)*8);
	if(flag==4)
	f="k.txt";
	fp=fopen(f,"a");
for(i=0;i<8;i++){
	
    for(j=0;j<8;j++){
    //	printf("%d",a[i*8+j]);
  
    	setbit(r+i,a[i*8+j],7-j);
	}
		
	//	printf("\n") ;
			
}
		
		
		
	for(i=0;i<8;i++){
		fputc(r[i],fp);			
	}	
		
	free(r);
	fclose(fp);
}



void filefix(char a[]){
	char ch;
	int del,len,i,flen;
	FILE *fp,*out;
	fp =fopen("k.txt","rb");
	out=fopen(a,"w");
	fseek(fp,-1,2);
	len=ftell(fp)+1;
   // printf("��%d\n",len);
	ch=fgetc(fp);
		if(ch>='A'){
			del=(int)(ch-'A'+10);
			
		}else{
			del=(int)(ch-'0');
			
		}		
//	printf("ɾ%d\n",del);	
	fseek(fp,0,0);
	flen=len-del;
//	printf("����%d\n",flen);
	for(i=0;i<flen;i++){
		ch=fgetc(fp);
		fputc(ch,out);
	}
	
	fclose(fp);
	fclose(out);
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}



































