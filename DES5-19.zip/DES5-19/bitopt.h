#include<stdio.h>
int getbit(char buf,int n){
	
	
	
	return (buf>>n)&0x01;
}



void setbit(char *buf,int t,int n){
	
	if(t==1){
	(*buf)|=1<<n;
	}
	if(t==0){
	(*buf)&=~(1<<n);
	}

}
