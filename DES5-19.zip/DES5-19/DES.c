#include<stdio.h> 
#include <stdlib.h>
#include <string.h>
#include "setkey.h"
#include "displace.h"
#include "shift.h"
#include "operation.h"
#include "fileget.h" 
#define N 20
int main(){
	int i,j,h,flag,len,count,flen,fill,ttt;
	char a[N],key[N],name[N],dstfilename[N];
	char *stmsg;
	int  *msg,*res,*s,*k,*p,*skey,*lr,*r,*cd,*c1,*d1,*r1,*l1,*temp,*smsg,*st;
	const static int LOOP[16] = {
    1,1,2,2,2,2,2,2,1,2,2,2,2,2,2,1
};
    const static int LOOP_R[16]={
	0,1,2,2,2,2,2,2,1,2,2,2,2,2,2,1
	};

	int l0[32],r0[32],c0[28],d0[28],gg[64];
	printf("***********************************************\n");
	printf("1 ����    2 ����    3 �ļ�����    4 �ļ�����\n");
	printf("***********************************************\n");
	scanf("%d",&flag);
	
if(flag<3){
	printf("������16λ���Ļ����ģ�");
	scanf("%s",a);	
	printf("������14λ��Կ��");
	scanf("%s",key);
}

else{
	printf("�������ļ�����");
	scanf("%s",name);
	printf("������Ŀ���ļ�����");
	scanf("%s",dstfilename);
	printf("��������Կ��");
	scanf("%s",key);	
	flen=filelen(name);
if(flag==3){
	if(flen%8!=0)
    	fill=8-flen%8;
    else{
    	fill=0;
	}	
    	
    	ttt=filefill(name,fill);
    	flen=flen+ttt;
    	printf("%d\n",ttt);
    
	
	
	
	
}
/////////////////////////////////////	

/////////////////////////////////
}
 


if(flag<3)
{
     msg=setmsg(a);
    if(msg[1]>=100){
    	msg[1]=msg[1]-100;
    	count=msg[0];
    	msg[0]=msg[0]-count;
	}else{
		count=msg[0]-1;
		msg[0]=msg[0]-count;	
	}
 //  printf("%d\n",count);
   
	skey=setkey(key);
	lr=ip_displace(msg);
	free(msg);	
    cd=pc1_displace(skey);
  
    
    for(i=0;i<64;i++){
    	
    	if(i<32)
    	{
		l0[i]=lr[i];
		}
    	else{
    		r0[i-32]=lr[i];

		}
    	  		

	}    
	
	

    for(i=0;i<56;i++){
    	
    	if(i<28)
    	{
		c0[i]=cd[i];
 
		}
    	else{
    		d0[i-28]=cd[i];
    	
		}
    	  	
	}  
    
    
    
r1=r0;
l1=l0;
    
 c1=c0;
 d1=d0;
 
/////////////////////////////////////���� 
 
 if(flag==1)
 {
 
for(i=0;i<16;i++)   {                          
c1=lshift(c1,LOOP[i]);
d1=lshift(d1,LOOP[i]);    
k=pc2_displace(c1,d1);  //kn 
temp=r1;
r=e_displace(r1);

res=operation(r,k);    //16��1 
free(k);
free(r);
s=s_displace(res);     //16��2 
free(res);
p=p_displace(s);       //16��3 
r1=operation2(p,l1);
l1=temp;

}

smsg=ipr_displace(r1,l1);
getmsg(smsg);

}
/////////////////////////////////////���� 
if(flag==2){
for(i=0;i<16;i++)   {    


                      
c1=rshift(c1,LOOP_R[i]);
d1=rshift(d1,LOOP_R[i]);    


k=pc2_displace(c1,d1);  //kn 
temp=r1;
r=e_displace(r1);
res=operation(r,k);    //16��1 
free(k);
free(r);
s=s_displace(res);     //16��2 
free(res);
p=p_displace(s);       //16��3 
r1=operation2(p,l1);
l1=temp;

}

smsg=ipr_displace(r1,l1);
getmsg(smsg);
	
}

}






else{
	
	
	
	
printf("%d\n",flen);
for(h=0;h<flen/8;h++){
		
	
	
    msg=fileget(name,h,flag);   
    skey=setkey(key);
	lr=ip_displace(msg);
	free(msg);	
	msg=NULL;
    cd=pc1_displace(skey);
  
    
    for(i=0;i<64;i++){
    	
    	if(i<32)
    	{
		l0[i]=lr[i];
		}
    	else{
    		r0[i-32]=lr[i];

		}
    	  		

	}    
	
	

    for(i=0;i<56;i++){
    	
    	if(i<28)
    	{
		c0[i]=cd[i];
 
		}
    	else{
    		d0[i-28]=cd[i];
    	
		}
    	  	
	}  
    
    
    
r1=r0;
l1=l0;

c1=c0;
d1=d0;
 
/////////////////////////////////////���� 
 
 if(flag==3)
 {
 
for(i=0;i<16;i++)   {                          
c1=lshift(c1,LOOP[i]);
d1=lshift(d1,LOOP[i]);    
k=pc2_displace(c1,d1);  //kn 
temp=r1;
r=e_displace(r1);

res=operation(r,k);    //16��1 
free(k);
k=NULL;
free(r);
r=NULL;
s=s_displace(res);     //16��2 
free(res);
res=NULL;
p=p_displace(s);       //16��3 
r1=operation2(p,l1);
l1=temp;

}

free(p);
p=NULL;
free(s);
s=NULL;
smsg=ipr_displace(r1,l1);

fileput(smsg,dstfilename,flag);
free(smsg);
smsg=NULL;
free(r1);
r1=NULL;
//free(c1);
//free(d1);
free(lr);
lr=NULL;
}

/////////////////////////////////////���� 
if(flag==4){
for(i=0;i<16;i++)   {    
                      
c1=rshift(c1,LOOP_R[i]);
d1=rshift(d1,LOOP_R[i]);    


k=pc2_displace(c1,d1);  //kn 
temp=r1;
r=e_displace(r1);
res=operation(r,k);    //16��1 
free(k);
free(r);
s=s_displace(res);     //16��2 
free(res);
p=p_displace(s);       //16��3 
r1=operation2(p,l1);
l1=temp;

}


free(p);
free(s);
smsg=ipr_displace(r1,l1);
fileput(smsg,dstfilename,flag);	
free(smsg);
free(r1);
//free(c1);
//free(d1);
free(lr);
//


}	
	
}
if(flag==4){
filefix(dstfilename);
}




}



printf("%d\n",h);
flen=filelen("res.txt");
printf("res���ȣ�%d\n",flen);
///////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////

if(flag==3)	{
	printf("�ļ����ܳɹ�"); 
}else{
	
	printf("�ļ����ܳɹ�"); 
	
}

	
	


	
	}
	
	
	
	
	

	
	
	


