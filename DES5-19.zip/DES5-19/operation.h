#include<stdio.h> 
#include <stdlib.h>
int* operation(int a[],int b[]) {
	int *res;
	int i;
	res=(int*)malloc(sizeof(int)*48);
	for(i=0;i<48;i++){
		if(a[i]-b[i]==0){
			res[i]=0;
		}else{
			res[i]=1;
		}
//		printf("%d",a[i]);
	}
//	printf("\n");
//	for(i=0;i<48;i++){	
//		printf("%d",b[i]);
//	}
//		printf("\n");
//	for(i=0;i<48;i++){	
//		printf("%d",res[i]);
//	}
//	printf("\n");
//		
	return res;	
}



int* operation2(int a[],int b[]) {
	int *res;
	int i;
	res=(int*)malloc(sizeof(int)*32);
	for(i=0;i<32;i++){
		if(a[i]-b[i]==0){
			res[i]=0;
		}else{
			res[i]=1;
		}
//		printf("%d",a[i]);
	}
//	printf("\n");
//	for(i=0;i<48;i++){	
//		printf("%d",b[i]);
//	}
//		printf("\n");
//	for(i=0;i<32;i++){	
//		printf("%d",res[i]);
//	}
//	printf("\n");
//		
	return res;	
}
