
#include<stdio.h> 
#include <stdlib.h>
#include <math.h>
#include<string.h>
//���Ļ�ȡ 


int *setmsg(char a[]){
	int i,j,num,temp=0,len,count=0;
	int *msg;
    msg= (int*)malloc(sizeof(int)*64);
	int dmsg[16]={0};
	if(strlen(a)<16){
		
		len=strlen(a);
		for(i=0;len+i<16;i++){
		a[len+i]='0';
		count++;
		}
	}
	
for(i=0;i<16;i++){
		if(a[i]>='A'){
			dmsg[i]=(int)(a[i]-'A'+10);
			
		}else{
			dmsg[i]=(int)(a[i]-'0');
			
		}
		
		
}

for(i=0;i<16;i++){
	for(j=3+4*i;temp<4;j--){
        msg[j]=dmsg[i]%2;
		dmsg[i]=dmsg[i]/2;				
		temp++;
	}
    temp=0;
}


if(count!=0){
	
	
if(msg[0]==0){
    	msg[1]=msg[1]+100;
}
else{
		msg[1]=msg[1];
}
    msg[0]=msg[0]+count;
	
	
}





////////////////���� 
//
//      printf("����%s\n",a);
//	  printf("����������:");	
//	for(i=0;i<64;i++){
//		
//		printf("%d",msg[i]);
//	}
//	    printf("\n");
//	    
//	    
/////////////////����	    
	    
	    
	    
	    
	 
return msg;

}



//��Կ��ȡ 
int* setkey(char a[]){
	int i,j,num,temp=0,flag=0,len;
	int dkey[14]={0};
	int k[56];
	int *key;
	key=(int*)malloc(sizeof(int)*64);
	
	
	if(strlen(a)<14){
		
		len=strlen(a);
		for(i=0;len+i<14;i++){
		a[len+i]='0';
		}
		
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
for(i=0;i<14;i++){
		if(a[i]>='A'){
			dkey[i]=(int)(a[i]-'A'+10);
			
		}else{
			dkey[i]=(int)(a[i]-'0');
			
		}
}

for(i=0;i<14;i++){
	for(j=3+4*i;temp<4;j--){
        k[j]=dkey[i]%2;
		dkey[i]=dkey[i]/2;				
		temp++;
	}
    temp=0;
}
    	

for(i=1;i<=8;i++){
	for(j=7*(i-1);j<7*i;j++){
		
		
		flag=flag+k[j];
        key[j+i-1]=k[j];
		
	}
	
		if(flag%2==1){
		key[j+i-1]=0;    //��У�� 
			
	}   
	   else{
		key[j+i-1]=1;
			
		
	}

		flag=0;
}	
///////////////////���� 
//printf("��Կ:");
//	for(i=0;i<64;i++){
//		
//		printf("%d",key[i]);
//		if((i-7)%8==0){
//			printf(" ");
//		}
//		
//	}
//	    printf("\n");
	    
//////////////////����	    
	return key;
}


char* getmsg(int a[]){
	int i,j,t=0;
    int dmsg[16]={0};
    char *msg; 
    msg=(char*)malloc(sizeof(char)*16);
    for(i=0;i<64;i+=4){
    	
    	for(j=0;j<4;j++){
          dmsg[t]=dmsg[t]+a[i+j]*pow(2,3-j);
    		
    		
		}
    		
    	t++;	
    		
	} 
/////////////����	
//      printf("����������:");
//	 for(i=0;i<64;i++){
//	 	printf("%d",a[i]);
//	 }
//	  printf("\n");	
//      printf("ʮ��������:");
//	 for(i=0;i<16;i++){
//	 	printf("%d ",dmsg[i]);
//	 }
//	  printf("\n");
/////////////����	 
	 
	 
	    printf("����:");
	 for(i=0;i<16;i++){
	 	if(dmsg[i]>=10){
	 		msg[i]=dmsg[i]-10+'A';
	 		
		 }else{
		 	msg[i]=dmsg[i]+'0';
		 }
	 	
	 	
	 	
	 	printf("%c ",msg[i]);
	 	
	 }
	
	
	return msg;
	
}

























